const express = require('express');

const app = express();
const PORT = 3000;

// Middleware for parsing JSON data and form data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Endpoint for communication from Unity to Node.js
app.post('/unity', (req, res) => {
    const dataFromUnity = req.body;
    console.log('Received form data:', dataFromUnity); 

    // Process the data received from Unity
    const responseToUnity = {
        status: 'success',
        message: 'Data received and processed',
    };

    // Send a response back to Unity
    res.json(responseToUnity);
});

// Endpoint for communication from Node.js to Unity
app.get('/send-to-unity', (req, res) => {
    const dataForUnity = {
        message: 'Hello Unity!',
        timestamp: Date.now(),
    };

    // Send the data as JSON
    res.json(dataForUnity);
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});


